const { Given, When, Then } = require("@wdio/cucumber-framework");

const SimpleSearch = require("../pageobjects/simpleSearchPageObject");

Given(/^I am on the home page and clicking the Find the cause$/, async () => {
  await SimpleSearch.openUrl();
  await SimpleSearch.findCause();
});

When(/^Enter the search and check in the list$/, async () => {
  await SimpleSearch.valueText();
  await SimpleSearch.checkForcause();
  await SimpleSearch.buttonSubmit();
});

Then(
  /^Confirming the Cause exists in the Search results Message$/,
  async () => {
    console.log("Display message");
    await SimpleSearch.message();
  }
);
