class SimpleSearch {
  get findCauseXpath() {  // Getting the Xpath of the find the cause
    return $(
      "//span[@class='style_underline__2Jjwh' and contains(., 'Find a cause')]"
    );
  }

  get cookeXpath() // Getting the Xpath of the Cookie appearing in the page
  {
    return $("//button[contains(@class,'bg-primary text-ink-500 text-center hover')]");
  }
  get sBox() {   // Getting the Xpath of the Searchtextbox
    console.log("ebbter in to the box");
    return $("//input[@id='sagc-hero-search-input']");
  }
  get dropBox() { // Getting the Xpath of DropBox 
    return $("//ul[@id='sagc-hero-search-input-auto-suggest']");
  }
  get xpathSubmit() { // Getting the Xpath of Submit
    return $("//button[@id='sagc-hero-search-submit']");
  }

  //actions

  async openUrl() {  //  Method for opening the Url
    await browser.url("https://www.easyfundraising.org.uk/");
    await browser.pause(4000);
    await this.cookeXpath.click();
    await browser.maximizeWindow();
    await browser.pause(5000);
  }

  async findCause() {  //  Method for clicking the Find a cause
    console.log("Print the Text", await this.findCauseXpath.getText());
    await this.findCauseXpath.click();
    console.log("Clicked the Find the cause checking for the title matching");
    expect(browser).toHaveTitle("Support a Good Cause | Easyfundraising");
    console.log("The title matched and Find the Cause is Clicked");
    await browser.pause(5000);
  }

  async valueText() {//  Method for getting the Text 
    
    await this.sBox.addValue("can");

    await browser.pause(5000);
  }

  async checkForcause() {  //  Method for getting the Text and Fixing the 3rd Cause
    await browser.pause(3000);
    var text = await this.dropBox.$$("li")[2].$("button").getText();

    if (text === "Marie Curie Cancer Care") {
      await this.dropBox
        .$$("li")[2]
        .$(
          "//button[@class='style_suggestionBtn__47Wy4' and contains(., 'Marie Curie Cancer Care')]"
        )
        .click();
      await browser.break;
    }
    await browser.pause(5000);
  }

  async buttonSubmit() { //  Method for clicking the Submit
    await this.xpathSubmit.click();
    //console.log(browser.getText());
  }

  async message() {  // Checking for the Url and Displaying the Message
    if (
      expect(browser).toHaveUrl(
        "https://www.easyfundraising.org.uk/search/cause/?q=Marie%20Curie%20Cancer%20Care&cat=cause"
      )
    ) {
      console.log("*******The cause exists*******");
    } else {
      console.log("The cause doesn't exists");
    }
  }
}
module.exports = new SimpleSearch();
